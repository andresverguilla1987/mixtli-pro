// prisma/seed.js
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  // upsert del usuario demo
  await prisma.usuario.upsert({
    where: { email: 'demo@example.com' },
    update: {},
    create: { nombre: 'Usuario Demo', email: 'demo@example.com' }
  });
  console.log('Seed listo ✅');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
