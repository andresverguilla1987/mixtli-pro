require('dotenv').config();
const express = require('express');
const morgan = require('morgan');
const cors = require('cors');
const helmet = require('helmet');
const errorHandler = require('./src/middlewares/error');

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// Rutas base
app.get('/', (req, res) => {
  res.send({
    name: 'Mixtli Pro API',
    status: 'ok',
    docs: ['GET /salud', 'CRUD /api/users'],
    time: new Date().toISOString(),
  });
});

app.get('/salud', (req, res) => {
  res.status(200).json({ ok: true, time: new Date().toISOString() });
});

app.use('/api/users', require('./src/rutas/users'));

// Error handler al final
app.use(errorHandler);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 API en puerto ${PORT}`);
});
