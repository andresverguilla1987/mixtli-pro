# Mixtli Pro API (clean)

API limpia (Express + Prisma + PostgreSQL) con colección de Postman lista.

## Variables de entorno
Copia `.env.example` a `.env` y ajusta:
```
DATABASE_URL=postgresql://usuario:password@host:5432/mixtli_db?schema=public
PORT=10000
NODE_ENV=production
JWT_SECRET=pon_aqui_un_secreto_largo_y_unico
```

## Comandos
```
npm install
npx prisma generate
npx prisma db push   # o prisma migrate deploy si ya tienes migraciones
npm start
```

## Endpoints
- `GET /`            → info
- `GET /salud`       → healthcheck
- `GET /api/users`   → listar
- `POST /api/users`  → crear  (body: { email, password, nombre? })
- `GET /api/users/:id`
- `PUT /api/users/:id`  (body: { email?, password?, nombre? })
- `DELETE /api/users/:id`
```

## Notas
- Selecciona solo campos públicos: `email`, `nombre`, `createdAt`, `updatedAt`. El `passwordHash` nunca se expone.
- Incluimos el campo opcional `nombre` en el esquema por compatibilidad.
- En Postman, usa la colección incluida; crea usuario y se auto-guardará `userId` para las demás peticiones.
