require('dotenv').config();
const { Worker } = require('bullmq');
const prisma = require('../src/lib/prisma');
const Redis = require('ioredis');
const connection = new Redis(process.env.REDIS_URL);

const worker = new Worker('archivos', async (job) => {
  const { key } = job.data;
  // Marcamos processing
  await prisma.archivo.update({ where: { key }, data: { status: 'PROCESSING' } });
  // TODO: aquí podrías generar previews, validar checksum, transcodificar, etc.
  await new Promise(r => setTimeout(r, 500)); // simulate
  await prisma.archivo.update({ where: { key }, data: { status: 'READY' } });
  return { ok: true };
}, { connection });

worker.on('completed', (job) => console.log('✅ Job listo', job.id));
worker.on('failed', (job, err) => console.error('❌ Job falló', job?.id, err));
console.log('👷 Worker escuchando jobs...');
