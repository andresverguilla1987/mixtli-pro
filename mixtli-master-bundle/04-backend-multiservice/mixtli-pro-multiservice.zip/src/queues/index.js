const { Queue } = require('bullmq');
const { createClient } = require('ioredis');

const connection = new (require('ioredis'))(process.env.REDIS_URL);

const archivosQueue = new Queue('archivos', { connection });

module.exports = { archivosQueue, connection };
