const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const prisma = require('../lib/prisma');
const { client, CreateMultipartUploadCommand, CompleteMultipartUploadCommand, AbortMultipartUploadCommand, getSignedUrl } = require('../lib/s3');

const BUCKET = process.env.S3_BUCKET;

router.post('/multipart/init', async (req, res, next) => {
  try {
    const { filename, contentType } = req.body || {};
    if (!filename || !contentType) return res.status(400).json({ error: 'filename y contentType son requeridos' });
    const key = `uploads/${uuidv4()}-${filename}`;
    const cmd = new CreateMultipartUploadCommand({ Bucket: BUCKET, Key: key, ContentType: contentType });
    const resp = await client.send(cmd);
    await prisma.archivo.create({
      data: { id: uuidv4(), key, filename, contentType, status: 'UPLOADING' }
    });
    res.json({ key, uploadId: resp.UploadId, bucket: BUCKET });
  } catch (err) { next(err); }
});

router.get('/multipart/sign-part', async (req, res, next) => {
  try {
    const { key, uploadId, partNumber } = req.query;
    if (!key || !uploadId || !partNumber) return res.status(400).json({ error: 'key, uploadId y partNumber son requeridos' });
    const url = await getSignedUrl(client, {
      input: { Bucket: BUCKET, Key: key, UploadId: uploadId, PartNumber: Number(partNumber) },
      commandName: 'UploadPartCommand'
    }, { expiresIn: 3600 });
    res.json({ url });
  } catch (err) { next(err); }
});

router.post('/multipart/complete', async (req, res, next) => {
  try {
    const { key, uploadId, parts } = req.body || {};
    if (!key || !uploadId || !Array.isArray(parts)) return res.status(400).json({ error: 'key, uploadId y parts[] son requeridos' });
    const cmd = new CompleteMultipartUploadCommand({
      Bucket: BUCKET, Key: key, UploadId: uploadId,
      MultipartUpload: { Parts: parts.map(p => ({ ETag: p.ETag, PartNumber: Number(p.PartNumber) })) }
    });
    await client.send(cmd);
    await prisma.archivo.update({ where: { key }, data: { status: 'COMPLETE' } });
    // Encolar job de post-proceso
    const { archivosQueue } = require('../queues');
    await archivosQueue.add('postprocess', { key });
    res.json({ ok: true, key });
  } catch (err) { next(err); }
});

router.post('/multipart/abort', async (req, res, next) => {
  try {
    const { key, uploadId } = req.body || {};
    if (!key || !uploadId) return res.status(400).json({ error: 'key y uploadId son requeridos' });
    const cmd = new AbortMultipartUploadCommand({ Bucket: BUCKET, Key: key, UploadId: uploadId });
    await client.send(cmd);
    await prisma.archivo.update({ where: { key }, data: { status: 'FAILED' } });
    res.json({ ok: true });
  } catch (err) { next(err); }
});

module.exports = router;
