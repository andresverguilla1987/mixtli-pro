require('dotenv').config();
const express = require('express');
const morgan = require('morgan');
const cors = require('cors');
const helmet = require('helmet');
const errorHandler = require('./src/middlewares/error');

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(morgan('dev'));

app.get('/', (req, res) => res.send({ name: 'Mixtli Web', status: 'ok', time: new Date().toISOString() }));
app.get('/salud', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

app.use('/api/users', require('./src/rutas/users'));
app.use('/api/uploads', require('./src/rutas/uploads'));

app.use(errorHandler);

const PORT = process.env.PORT || 10000;
app.listen(PORT, () => console.log(`🚀 Web escuchando en ${PORT}`));
