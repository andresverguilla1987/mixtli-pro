# Mixtli Multiservicio (Web + Worker)

Pensado para **archivos grandes** rápido y estable:
- Subidas **multipart S3** (directo del cliente al bucket con URLs firmadas).
- **BullMQ + Redis** para procesar en background (previews, checksums, transcodificación).
- Web y Worker separados para escalar independiente.

## Variables (.env)
Ver `.env.example` y definir en el hosting:
- `DATABASE_URL`, `REDIS_URL`
- `S3_ENDPOINT`, `S3_BUCKET`, `S3_ACCESS_KEY`, `S3_SECRET_KEY`, `S3_REGION`, `S3_FORCE_PATH_STYLE`

## Endpoints clave
- `POST /api/uploads/multipart/init` → `{ filename, contentType }`
- `GET  /api/uploads/multipart/sign-part?key=&uploadId=&partNumber=`
- `POST /api/uploads/multipart/complete` → `{ key, uploadId, parts:[{ETag,PartNumber}] }`
- `POST /api/uploads/multipart/abort`

**Flujo:** init → cliente sube partes directo a S3 → complete → encolamos job → worker marca `READY` al terminar.

## Correr local
```
npm install
npx prisma generate
npx prisma db push
npm run start         # web
npm run worker        # worker
```

## Escalamiento
- Web: maneja auth, firma de partes y callbacks.
- Worker: CPU/IO pesado. Puedes subir plan sólo del worker sin tocar web.
