# Mixtli Uploader Frontend (Uppy + Multipart)

Frontend estático listo para Netlify/Render Static:
- Usa Uppy (Dashboard + AwsS3Multipart) desde CDN (sin build).
- Se conecta a tu backend con endpoints:
  - `POST /api/uploads/multipart/init`
  - `GET  /api/uploads/multipart/sign-part?key=&uploadId=&partNumber=`
  - `POST /api/uploads/multipart/complete`

## Uso
1. Abre `index.html` e introduce la **Base URL** de tu backend.
2. Arrastra archivos al cuadro. Ajusta **tamaño de parte** y **concurrencia**.
3. Sube y mira progreso/logs.

## Deploy estático
- Netlify: arrastra la carpeta o usa `netlify deploy --prod`
- Render Static Site: crea un Static Site y sube el contenido.

## Tip tuning
- Partes 10–32MB + concurrencia 4–6 suele rendir mejor.
- Si tu navegador/ISP limita conexiones, reduce concurrencia.
- Siempre usa CDN para descargas rápidas del bucket.
