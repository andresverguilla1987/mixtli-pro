import {
  Uppy,
  Dashboard,
} from 'https://releases.transloadit.com/uppy/v3.25.2/uppy.min.mjs'
import AwsS3Multipart from 'https://releases.transloadit.com/uppy/v3.25.2/awss3-multipart.min.mjs'

const el = (id) => document.getElementById(id)
const logs = el('logs')
const log = (...args) => {
  const line = args.map(a => typeof a === 'string' ? a : JSON.stringify(a, null, 2)).join(' ')
  logs.textContent += line + "\n"
  logs.scrollTop = logs.scrollHeight
}

function getBaseUrl() {
  return el('baseUrl').value.replace(/\/$/, '')
}

function getPartSize() {
  const mb = parseInt(el('partSizeMB').value, 10) || 10
  return mb * 1024 * 1024
}

function getConcurrency() {
  return parseInt(el('concurrency').value, 10) || 4
}

let uppy

function bootUppy() {
  if (uppy) { uppy.close({ reason: 'user' }); uppy = null }

  uppy = new Uppy({
    restrictions: { maxNumberOfFiles: 10 },
    autoProceed: false
  })
  .use(Dashboard, {
    target: '#uppy',
    inline: true,
    proudlyDisplayPoweredByUppy: false,
    note: 'Soporta archivos gigantes. Se recomiendan partes 10–32MB.',
    showProgressDetails: true,
    hideUploadButton: false,
    height: 420
  })
  .use(AwsS3Multipart, {
    limit: getConcurrency(),
    // Tamaño de parte dinámico
    createMultipartUpload: async (file) => {
      const baseUrl = getBaseUrl()
      const resp = await fetch(`${baseUrl}/api/uploads/multipart/init`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filename: file.name,
          contentType: file.type || 'application/octet-stream'
        })
      })
      if (!resp.ok) throw new Error('init fallo')
      const json = await resp.json()
      log('init ok', json)
      return { uploadId: json.uploadId, key: json.key }
    },
    signPart: async (file, partData) => {
      const baseUrl = getBaseUrl()
      const url = `${baseUrl}/api/uploads/multipart/sign-part?key=${encodeURIComponent(partData.key)}&uploadId=${encodeURIComponent(partData.uploadId)}&partNumber=${encodeURIComponent(partData.partNumber)}`
      const resp = await fetch(url)
      if (!resp.ok) throw new Error('signPart fallo')
      const json = await resp.json()
      return { url: json.url }
    },
    completeMultipartUpload: async (file, { key, uploadId, parts }) => {
      const baseUrl = getBaseUrl()
      const resp = await fetch(`${baseUrl}/api/uploads/multipart/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key, uploadId, parts })
      })
      if (!resp.ok) throw new Error('complete fallo')
      const json = await resp.json()
      log('complete ok', json)
      return json
    },
    getChunkSize: () => getPartSize()
  })

  uppy.on('upload', () => log('⏫ Iniciando subida...'))
  uppy.on('progress', (p) => log('Progreso:', p + '%'))
  uppy.on('upload-success', (file, res) => log('✅ Exito:', file.name, res))
  uppy.on('error', (err) => log('❌ Error:', err.message || err))
  uppy.on('complete', (r) => log('🏁 Completado: archivos', r.successful.length, 'fallidos', r.failed.length))
}

bootUppy()

el('partSizeMB').addEventListener('change', bootUppy)
el('concurrency').addEventListener('change', bootUppy)
el('baseUrl').addEventListener('change', () => log('Base URL:', getBaseUrl()))
